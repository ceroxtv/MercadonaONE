package com.mercadona.shopone;

public class MercadonaShopOne {
    Item[] item;

    public MercadonaShopOne(Item[] items) {
        this.item = items;
    }

    public void updateQuality() {
        for (Item item : item) {
            boolean isCheese = item.name.equals("Aged blue cheese");
            boolean isHam = item.name.equals("Ham");
            boolean isSalt = item.name.equals("Iodized salt");
            boolean isFrozen = item.name.equals("Frozen cake");

            if(item.quality > 0) {
                if(isFrozen) {
                    if(item.quality > 1) {
                        extracted(item,2,false);
                    }else {
                        item.quality = 0;
                    }
                }else if(isCheese) {
                    if(item.quality < 50) {
                        extracted(item,1,true);
                    }
                }else if(isHam) {
                    if(item.quality < 50) {
                        extracted(item,2,true);
                        if (item.sellIn < 11) {
                            if (item.quality < 50) {
                                extracted(item,1,true);
                            }
                        }
                        if (item.sellIn < 6) {
                            if (item.quality < 49) {
                                extracted(item,2,true);
                            }
                        }
                    }
                }
            }
            if (!isSalt) {
                item.sellIn -= 1;
            }
            if(item.sellIn < 0) {
                if(isFrozen) {
                    if(item.quality > 2) {
                        extracted(item,2,false);
                    }
                }else if(isCheese) {
                    if(item.quality < 50) {
                        extracted(item,1,true);
                    }
                }else {
                    item.quality = 0;
                }

            }
        }

            /*// ----------------------------------------------------------------------
            if (!isCheese && !isHam){
                if (item.quality > 0) {
                    if (!isSalt) {
                        if(!isFrozen){
                            item.quality -= 1;
                        }else if(item.quality > 1){
                            item.quality -= 2;
                        }else {
                            item.quality = 0;
                        }
                    }
                }
            } else {
                if (item.quality < 50) {
                    item.quality = item.quality + 1;

                    if (isHam) {
                        if (item.sellIn < 11) {
                            if (item.quality < 50) {
                                item.quality += 1;
                            }
                        }
                        if (item.sellIn < 6) {
                            if (item.quality < 50) {
                                item.quality +=1;
                            }
                        }
                    }
                }
            }
            if (!isSalt) {
                item.sellIn -= 1;
            }
            if (item.sellIn < 0) {
                if (!isCheese) {
                    if (!isHam) {
                        if(!isFrozen){
                            if (item.quality > 0) {
                                if (!isSalt) {
                                    item.quality -=1;
                                }
                            }
                        }else{
                            if (item.quality > 0) {
                                item.quality -= 2;
                            }
                        }
                    } else {
                        item.quality = 0;
                    }
                } else {
                    if (item.quality < 50) {
                        item.quality += 1;
                    }
                }
            }
        }*/
    }
    private void extracted(Item item, int x, boolean b) {
        if(b) 
            item.quality += x;
        item.quality -= x;
    }  
}