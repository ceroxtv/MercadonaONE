package com.mercadona.shopone;

public class MercadonaShopOne {
    Item[] item;

    public MercadonaShopOne(Item[] items) {
        this.item = items;
    }

    public void updateQuality() {
        // He decidio hacer un switch y extraer todos los posibles casos de uso en metodos faciles de leer
        for (Item item : item) {
            switch (item.name) {
                case "Aged blue cheese":
                    decreaseSellIn(item);
                    updateQualityForCheese(item);
                    break;
                case "Ham":
                    decreaseSellIn(item);
                    updateQualityForHam(item);
                    break;
                case "Frozen cake":
                    decreaseSellIn(item);
                    updateQualityForFrozen(item);
                    break;
                default:
                    if(!item.name.equals("Iodized salt")) {
                        decreaseSellIn(item);
                        updateQualityForOther(item);
                    }
                    break;
            }
        }
    }

    private void updateQualityForCheese(Item item) {
        if (item.sellIn < 0 && item.quality < 49) {
            increaseQuality(item);
            increaseQuality(item);
        }else if(item.sellIn > 0 && item.quality < 50) {
            increaseQuality(item);
        }
    }
    private void updateQualityForHam(Item item) {
        increaseQuality(item);
        if (item.sellIn < 11 && item.quality < 50) {
            increaseQuality(item);
        }
        if (item.sellIn < 6 && item.quality < 50) {
            increaseQuality(item);
        }
        if (item.sellIn <= 0) {
            item.quality = 0;
        }
    }
    private void updateQualityForSalt(Item item) {
        decreaseSellIn(item);
    }
    private void updateQualityForFrozen(Item item) {
        if (item.sellIn < 0) {
            decreaseQuality(item, 4);
            if(item.quality < 0){
                item.quality = 0;
            }
        } else {
            decreaseQuality(item, 2);
            if(item.quality < 0){
                item.quality = 0;
            }
        }
    }
    private void updateQualityForOther(Item item) {
        if (item.sellIn > 0 && item.quality >0) {
            decreaseQuality(item, 1);
        }else if(item.sellIn < 1 && item.quality >1) {
            decreaseQuality(item, 2);
        }
        if(item.quality<1) {
            item.quality = 0;
        }
    }
    private void increaseQuality(Item item) {
        if (item.quality < 50) {
            item.quality++;
        }
    }
    private void decreaseQuality(Item item, int value) {
        if (item.quality > 0) {
            item.quality -= value;
        }
    }
    private void decreaseSellIn(Item item) {
        item.sellIn--;
    }

}