package com.mercadona.shopone;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MercadonaShopOneTest {

    @Test
    void itemGenericNotExpired() {
        Item[] items = new Item[] { new Item("generic", 3, 6) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("generic", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(5, app.items[0].quality);
    }

    @Test
    void itemGenericExpired() {
        Item[] items = new Item[] { new Item("expired", 0, 6) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("expired", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(4, app.items[0].quality);
    }

    @Test
    void itemGenericQuality() {
        Item[] items = new Item[] { new Item("expired", 3, 0) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("expired", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
    }

    @Test
    void cheeseNotExpired() {
        Item[] items = new Item[] { new Item("Aged blue cheese", 2, 0) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(1, app.items[0].sellIn);
        assertEquals(1, app.items[0].quality);
    }

    @Test
    void cheeseBetterQuality() {
        Item[] items = new Item[] { new Item("Aged blue cheese", 3, 50) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(50, app.items[0].quality);
    }


    @Test
    void cheeseExpired() {
        Item[] items = new Item[] { new Item("Aged blue cheese", 0, 0) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(2, app.items[0].quality);
    }

    @Test
    void hamNotExpired() {
        Item[] items = new Item[] { new Item("Ham", 15, 20) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(14, app.items[0].sellIn);
        assertEquals(21, app.items[0].quality);
    }

    @Test
    void hamExpired() {
        Item[] items = new Item[] { new Item("Ham", 0, 20) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
    }

    @Test
    void hamCuasiExpired() {
        Item[] items = new Item[] { new Item("Ham", 7, 20) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(6, app.items[0].sellIn);
        assertEquals(22, app.items[0].quality);
    }

    @Test
    void hamCloseExpired() {
        Item[] items = new Item[] { new Item("Ham", 3, 20) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(23, app.items[0].quality);
    }

    @Test
    void hamBetterQuality() {
        Item[] items = new Item[] { new Item("Ham", 3, 49) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(50, app.items[0].quality);
    }

    @Test
    void saltCloseExpired() {
        Item[] items = new Item[] { new Item("Iodized salt", 3, 80) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Iodized salt", app.items[0].name);
        assertEquals(3, app.items[0].sellIn);
        assertEquals(80, app.items[0].quality);
    }

    @Test
    void frozenCloseExpired() {
        Item[] items = new Item[] { new Item("Frozen cake", 3, 20) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(18, app.items[0].quality);
    }

    @Test
    void frozenExpired() {
        Item[] items = new Item[] { new Item("Frozen cake", 0, 20) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(16, app.items[0].quality);
    }

    @Test
    void frozenQualityExpired() {
        Item[] items = new Item[] { new Item("Frozen cake", 2, 1) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(1, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
    }




}
