#!/bin/bash

./mvnw exec:java test-compile -D"exec.mainClass"="com.mercadona.shopone.Run" -D"exec.classpathScope"="test" -D"exec.args"="$1"