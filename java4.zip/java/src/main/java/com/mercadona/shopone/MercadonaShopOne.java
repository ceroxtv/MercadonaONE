package com.mercadona.shopone;

public class MercadonaShopOne {
    Item[] item;

    public MercadonaShopOne(Item[] items) {
        this.item = items;
    }

    public void updateQuality() {
        for (Item item : item) {
            boolean isCheese = item.name.equals("Aged blue cheese");
            boolean isHam = item.name.equals("Ham");
            boolean isSalt = item.name.equals("Iodized salt");
            boolean isFrozen = item.name.equals("Frozen cake");

            if (!isSalt) {
                extractedDay(item,1,false);
            }else {
                extracted(item,1,true);
            }

            if (item.sellIn < 0) {
                if (isCheese && item.quality < 50) {
                    extracted(item,1,true);
                } else if (isFrozen) {
                    extracted(item,2,false);
                } else {
                    extracted(item,1,false);
                }
            }
            if (!isCheese && !isHam) {
                if (item.quality > 1) {
                    if (isFrozen) {
                        extracted(item,2,false);
                    } else {
                        extracted(item,1,false);
                    }
                }else {
                    item.quality=0;
                }
            } else {
                if (item.quality < 50) {
                    extracted(item,1,true);
                    if (isHam) {
                        if (item.sellIn < 11 && item.quality < 50) {
                            extracted(item,1,true);
                        }
                        if (item.sellIn < 6 && item.quality < 50) {
                            extracted(item,1,true);
                        }
                        if(item.sellIn<=0){
                            item.quality = 0;
                        }
                    }
                }
            }
        }
    }
    private void extracted(Item item, int x, boolean b) {
        if(b){
            item.quality+=x;
        }else {
            item.quality-=x;
        }
    }

    private void extractedDay(Item item, int x, boolean b) {
        if(b){
            item.sellIn+=x;
        }else {
            item.sellIn-=x;
        }
    }

}